
% ABENM (Hybrid model) to demonstrate utility of ABENM for modelling low
% prevalence diseases
%% Alex Forsyth 2022, method of restricting the network is largely based on the work of Zienkiewicz et al.

% This is the class library, run from Run_Hybrid_Model_2.m

%% The model

classdef Hybrid_Model_2 < handle
 
    properties
        %% Population states (i.e. all the states in which individuals aren't distinguiahed) Defined in run_script)
        N; %1 x 2 matrix. 
        S; %1 x 2 matrix. As above but all are suscpetible  
        I; %1 x 2 matrix. As above but all are infected. NB S(i,j) + I(i,j) = N(i,j) for all i,j member of [1,2]. 
        
      
        %% Network and agent states
        Q; %scalar; number of people currently modelled in the network 
        adj_full; %Q x Q unrestricted adjacency matrix
        adj; %Q x Q restricted adjacency matrix
        indiv_state; %Q x 1 vector, where 1 indicates infection
        symp; %Q x 1 vector, where 1 indicates agent is symptomatic
        sex; %Q x 1 vector, where 0 indicates male and 1 indicates female. Might be uneccesary, see if I can just use index position like in AMR_IBM_VAC
        d; %Q x 1 vector, detailing the desired degree of each node in the network
        %d_out; %(N - Q) x 1 vector; desired degree for  each person outside the network. Dont think this is needed
        v; % max(MAX_DEG) x 2 vector number of susceptible nodes in the network with each degree
        u; % "" but in compartments. 
        degree_delta; %difference between a nodes desired degree and current degree, i.e. how many more connections it can support.
        vaccinated; %Q x 2 vector, where a 1 in the first column indicates an agent is vaccinated and the number in the second column denotes the level of protection 
        NN_coverage; %Proportion of the non-network individuals who are vaccinated. This updates only for untargetted vaccination.
        currently_tracing_for; %Q x 1 
        treated_on; %Q x 1 vector, day on which an agent recovered via treatment
        

        % Network Restriction states
        id_casuals;
        num_partners_full;
        num_partners;
        fixed_rels;
        other_rels;
        rel_list_full;


        counters; %structure containing various data
        % Fields in self.data
        %   infect_day  Number of people newly infected each day
        %   total_infected       total number of people infected each day (Nb the nth day is in the n+1th position, due to day zero)
        % Should have something(s) to see if the network is behaving

      
        %% Other states
        today;
        %% Parameters ?* Order these
        ALPHA; %2 x 1 vector, where Alpha(1) is slope of male scale free network and Alpha(2) is slope of female sf network
        BETA; %2 x 1 vector; BETA(1) is rate at which males are infected, BETA(2) is rate at which females are infected
        SYM_RATE; %2 x 1 vector, where SYM_RATE(1) is the probability that an infected male is assigned symptoms, (2) the same for females
        MAX_DEG; %2 x 1 vector; MAX_DEG(1) is the max degree of males, MAX_DEG(2) is the max degree of females
        P0; %2 x 1 vector; P0(1) is initial prevalence of disease in males, p0(0) is initial prevalence in females (defined in run script)
        PAUSE_LENGTH; %number of seconds to pause when displaying the graphics
        TRACE_WINDOW; %2 x 1 vector, defining the time period for which contacts of agents who have recovered via treatment will be traced for
        GAMMA; % rate at which people naturally recover
        PSI; % tracing efficiency
        SELF_SEEK_PROB; %probability of a person seeking treatment if they have symptoms (/day)
        % Enable/ disable feature parameters
        ENABLE_GRAPHICS;
        RESTRICT_MAX_PARTNERS;
        FULL_MAX_PARTNERS;
        RESTRICT_PERIOD;
        infect_from_nonHet;


       
        % Vaccine Parameters (ignore for now)
        ALLOW_VACCINE_DEG;
        ALLOW_VACCINE_TAKE;
        OFFER_VAC_AT_TREAT; 
        VAC_UPTAKE_TREAT; %scaler. probability that an infected person accepts a vaccine when offered
        OFFER_VAC_UNTARGET;
        VAC_UPTAKE_UNTARGET; %scaler denoting the rate at which people accept a vaacine in an untargeted roll out
       
        VAC_INIT_COVERAGE;
        EFFICACY_DEG; %
        EFFICACY_TAKE


    end
    
    methods
    %% Class constructor
        function [self] = Hybrid_Model_2(N,params_hybrid) 
            
            % ###  Assign values to properties
            
            % Retrieve parameters 
            self.P0 = params_hybrid.P0;
            self.ALPHA = params_hybrid.ALPHA;
            self.BETA = params_hybrid.BETA;
           
            self.SYM_RATE = params_hybrid.SYM_RATE;
            self.MAX_DEG = params_hybrid.MAX_DEG;
            self.PAUSE_LENGTH = params_hybrid.pause_length;
            self.ENABLE_GRAPHICS = params_hybrid.ENABLE_GRAPHICS;
            self.ALLOW_VACCINE_DEG = params_hybrid.ALLOW_VACCINE_DEG;
            self.ALLOW_VACCINE_TAKE = params_hybrid.ALLOW_VACCINE_TAKE;
            self.VAC_UPTAKE_TREAT = params_hybrid.VAC_UPTAKE_TREAT;
            self.VAC_UPTAKE_UNTARGET = params_hybrid.VAC_UPTAKE_UNTARGET;
            self.EFFICACY_DEG = params_hybrid.EFFICACY_DEG;
            self.OFFER_VAC_AT_TREAT = params_hybrid.OFFER_VAC_AT_TREAT;
            
            self.OFFER_VAC_UNTARGET = params_hybrid.OFFER_VAC_UNTARGET;
            self.VAC_INIT_COVERAGE = params_hybrid.VAC_INIT_COVERAGE;
            self.EFFICACY_TAKE = params_hybrid.EFFICACY_TAKE;

            self.TRACE_WINDOW = params_hybrid.TRACE_WINDOW; %2 x 1 vector, defining the time period for which contacts of agents who have recovered via treatment will be traced for
            self.GAMMA = params_hybrid.GAMMA; % rate at which people naturally recover
            self.PSI = params_hybrid.PSI; % tracing efficiency
            self.SELF_SEEK_PROB = params_hybrid.SELF_SEEK_PROB;

            self.RESTRICT_MAX_PARTNERS = params_hybrid.RESTRICT_MAX_PARTNERS;
            self.FULL_MAX_PARTNERS = params_hybrid.FULL_MAX_PARTNERS;
            self.RESTRICT_PERIOD = params_hybrid.RESTRICT_PERIOD;

            % Other assignments/ initialisation
            self.N = N;
            self.indiv_state = [];
            self.symp = [];
            self.S = N;
            self.I = [0,0];
            self.d = [];
            self.v = []; 
            self.u = [];
            self.degree_delta = [];
            self.sex = [];
            self.today = 0; 
            self.vaccinated = [];
            self.NN_coverage = self.VAC_INIT_COVERAGE;
            self.currently_tracing_for = []; %Q x 1 
            self.treated_on(self.Q) = [];
            self.id_casuals = [];
            self.num_partners_full = [];
            self.num_partners = [];
            self.fixed_rels = [];
            self.other_rels = [];
            self.rel_list_full = [];

            % Counters
            self.counters = struct;
            self.counters.n_vaccinated = 0;
            self.counters.incidence = 0;
            self.counters.prevalence = 0;
            self.counters.Q = 0;
%             self.prev_offered_vac = []; Not in use atm

            

            % ### Initial Infection ###

            % Number of males to infect
            num_to_infect_m = floor(sum(self.N(1)) * self.P0(1)); %number of males to infect
            
            % Number of females to infect
            num_to_infect_f = floor(sum(self.N(2)) * self.P0(2)); %number of females to infect
            
            

            % Update compartments !* does this need moving?        
        
            self.S = self.S - [num_to_infect_m, num_to_infect_f]; %update susceptible compartments
            self.I = self.I + [num_to_infect_m, num_to_infect_m]; %update infected compartments

            self.counters.total_infected= sum(self.I); %update infection counter

            %### Set up the network ###

            [self] = self.create_network(self);



%             % ### Initial vaccination ### (this has been moved to {network_creator}
% 
%             idx_to_vaccinate = rand(self.Q,1) < self.VAC_INIT_COVERAGE; %
%             [self] = self.vaccinate(idx_to_vaccinate);

          
           % degree sequence of full network generated 
                % (from row sums of adjacency matrix)
%                 self.num_partners_full = full(sum(self.adj_full,2));
% 
%                
%                 
%                 % set default daily partnership network
%                 self.adj = self.adj_full;
%                 self.num_partners = self.num_partners_full;
%                 
%                 % restrict daily partnership network by limiting -----
%                 % individuals to a max number of partners per day
%                 partner_check = self.num_partners_full - self.RESTRICT_MAX_PARTNERS; %A F: How many partners to bin
%                 self.id_casuals = [find(partner_check > 0), partner_check(partner_check>0)]; % AF: [index of people deemed too promiscuous, degree of transgression]
%                 
%                 % pre-calculate fixed and prunable links
%                 self.fixed_rels = self.rel_list_full; 
%                 
%                 % fixed links  (won't include any links to nodes with
%                 % degree > threshold) 
%                 for i = self.id_casuals(:,1)' 
%                     id_remove = self.fixed_rels(:,1) == i | self.fixed_rels(:,2) == i;
%                     self.fixed_rels(id_remove,:) = []; 
%                 end
%                 % prunable links AF: all the links that connect to someone
%                 % who has been deemed too promiscuous
%                 self.other_rels = setdiff(self.rel_list_full, self.fixed_rels,'rows');
               
              
                self.restrict_adj3();


            % Display the network
            if self.ENABLE_GRAPHICS == true
                self.display_network();
            end

        end

        %% Simulate
        function [self] = simulate(self,n_Days)
            
            % ### Resize counters ###
            
                self.counters.n_vaccinated = [self.counters.n_vaccinated;zeros(n_Days,1)];
                self.counters.total_infected = [self.counters.total_infected;zeros(n_Days,1)];
                self.counters.incidence = [self.counters.incidence;zeros(n_Days,1)];
                self.counters.Q = [self.counters.Q;zeros(n_Days,1)];

               

            % ### Check chosen properties don't break anything ###
            
                % Don't allow degree type and take type protection simult
                if self.ALLOW_VACCINE_DEG == true && self.ALLOW_VACCINE_TAKE == true
                    error('Both types of vaccine protection enabled. Disable at least one.')
                end
                
                %Don't allow more than one vaccine distribution strategy (for
                %now at least, potentially could combine them later)
                if self.OFFER_VAC_AT_TREAT == true && self.OFFER_VAC_UNTARGET == true
                    error('More than one vaccine distribution strategy enabled. Disable at least one')
                end
%       
%           Update Q
            self.counters.Q  = self.Q
            % ### Start the simulation ###
           
            while self.today < n_Days 

                % TESTING ONLY:
%                 if self.today == (n_Days -1)
%                     pause
%                 end

                % Update the current day
                self.today = self.today + 1;

                % Restrict if it's a restriction day
                if mod(self.today,self.RESTRICT_PERIOD) == 0
                    [self] = self.restrict_adj3();
                end


                % ### Spread the infection ###
                
                [self] = self.spread_infection();

                % Update prevalence counter
                self.counters.prevalence(self.today+1) = sum(self.I);

                % ### See who recovers ###

                [self] = self.recovery();

                % ### Update counters ### 
                self.counters.total_infected(self.today + 1) = sum(self.I);
                
                % ### Update the vaccine coverage for untargetted distribution (if enabled)
                
                if self.OFFER_VAC_UNTARGET == true
                    
                    % Non-network coverage
                    self.NN_coverage = self.NN_coverage + (self.N - self.Q) * self.VAC_UPTAKE_UNTARGET; %
                   
                    % Newly vaccinated agents
                    newly_vaccinated = rand(self.Q) < ~self.vaccinated(:,1) * self.VAC_UPTAKE_UNTARGET;
                    
                    % Send to vaccinate method
                    [self] = self.vaccinate(newly_vaccinated);
                end

                % ### Display the network ###

                if self.ENABLE_GRAPHICS == true
                    self.display_network();
                end
                

            end
  
        end

        %% Spread the infection (and update the network)
        function [self] = spread_infection(self)
           %Output: new_agents is a Q x 1 logical array  
            
            % Save current Q
            old_Q = self.Q;

            % ### See who gets infected ###
            
            num_inf_conts = self.adj * self.indiv_state; %number of infected contacts per agent
        
            infect_force_m = (1 - (( 1 - repmat(self.BETA(1),self.Q,1)) .^ num_inf_conts )) .* ~self.indiv_state .* ~self.sex .* (1 - self.vaccinated(:,2)); %Infect force for males, masking those already infected and females
            % and including vaccination
            
            infect_force_f = (1 - (( 1 - repmat(self.BETA(2),self.Q,1)) .^ num_inf_conts )) .* ~self.indiv_state .* self.sex .* (1 - self.vaccinated(:,2)); %Infect force for females, masking those already infected and males
            
            % Males to infect
            log_idx_infect_m = rand(self.Q,1) < infect_force_m; %logical index of males to infect !* these two bits can be combined
            infect_m = find(log_idx_infect_m); % numerical index of males to infect
            
            % Females to infect
            log_idx_infect_f = rand(self.Q,1) < infect_force_f; %logical index of females to infect
            infect_f = find(log_idx_infect_f); % numerical index of females to infect
        
            infect_all = [infect_m; infect_f]; %combined list of newly infected people. Update indiv_state later on.
            
            % Update compartments
            self.S = self.S - [length(infect_m), length(infect_f)]; %update susceptible compartments
            self.I = self.I + [length(infect_m), length(infect_f)]; %update infected compartments
            
            % Update symptoms state vector
            self.symp(infect_m) = rand(length(infect_m),1) < self.SYM_RATE(1); %assign symptoms to males
            self.symp(infect_f) = rand(length(infect_f),1) < self.SYM_RATE(2); %assign symptoms to females

            % ### Update network ###
           

            for ii = randperm(length(infect_all))
                j = infect_all(ii); %random selection of one of the newly infected nodes
                
                while self.degree_delta(j) > 0
                    
                    % Find degree of new contact
                    total_v = self.v + self.u; %total people left of each degree
                    v_bins = [0 ;cumsum(total_v(:,2-self.sex(j)))/sum(total_v(:,2-self.sex(j)))]; %returns v bins of female degrees if j is male, male degrees if j is female. (That's what 2-self.sex(j) is doing)
                    new_degree = discretize(rand(1),v_bins); %degree of new node to be connected to j


                    % Decide where to draw from (compartment or network) !* Feel like there must be a better way to do this. Does it even work?
                    net_elig_prop = (self.v(new_degree,2-self.sex(j)) - sum(self.adj_full(:,j) .* ~self.indiv_state .* (self.d == new_degree)))...
                        / total_v(new_degree,2-self.sex(j)); %proportion of correct sex, degree new_degree population, in network (not already connected)
                    
                    if rand < net_elig_prop %draw from network
                        % Find possible contacts (sex, infection, attachment) 
                        pos_contacts = find(~self.adj_full(:,j) .* ~self.indiv_state .* (self.d == new_degree) .* (self.sex ~= self.sex(j)));
                        
                    % If there are no eligible nodes, then move on the the next iteration of the if-loop. !* should this instead find the closest degree node
                        if numel(pos_contacts) == 0
                            self.degree_delta(j) = self.degree_delta(j) - 1; %need to remove one from degree_delta, or we'll be stuck in the while-loop forever.
                            continue
                        end

                        % Pick one at random (uniform)
                        new_contact = randsample(pos_contacts,1);

                        % Update adj_full and degree_delta
                        self.adj_full(j,new_contact) = 1; self.adj_full(new_contact,j) = 1; 
                        self.degree_delta([j,new_contact]) = self.degree_delta([j,new_contact]) - 1;                           
                        
                    else %draw from non-network

                        self.v(new_degree,2-self.sex(j)) = self.v(new_degree,2-self.sex(j)) + 1; %add to v_net
                        self.u(new_degree,2-self.sex(j)) = self.u(new_degree,2-self.sex(j)) - 1; %remove from v_comp

                        % Update other state arrays
                        self.Q = self.Q + 1; %nb the network index of added nodes will always be Q + 1
                        self.adj_full(j,self.Q) = 1; self.adj_full(self.Q,j) = 1; %add the new edge to the full adjacency matrix
                        self.adj(j,self.Q) = 1; self.adj(self.Q,j) = 1; %update the size of the restricted adj. Nb the link is not imediately admitted to the retricted adj to allow for an incubation period
                        self.d(self.Q) = new_degree;
                        self.indiv_state(self.Q) = 0; %new nodes aren't infected to begin with
                        self.sex(self.Q) = 1 - self.sex(j); %new nodes are of the opposite sex to the infected node they're attaching to
                        self.symp(self.Q) = 0; %not infected so no symptoms
                        self.degree_delta(j) = self.degree_delta(j) - 1; 
                        self.degree_delta(self.Q) = new_degree - 1; % add the degree delta of the new node 
                        self.vaccinated(self.Q,:) = [0 0];
                        self.currently_tracing_for(self.Q) = 0; %Q x 1 
                        self.treated_on(self.Q) = NaN;
                        
                    end 
                          
                end 

            end %loop over all newly infected nodes       
           
            % ### See who enters the network vaccinated ###
                
            % Is vaccination enabled?
            if self.ALLOW_VACCINE_DEG == true || self.ALLOW_VACCINE_TAKE == true
                 
                % Find logical indices of new agents
                new_agents = [zeros(old_Q,1);ones(self.Q-old_Q,1)]; 

                % Take a proportion of the new agents and send them to the vaccinate method
                to_vaccinate = rand(self.Q,1) < new_agents* self.NN_coverage; %NN_COVERAGE only updates for  untargetted distribution strat

                [self] = self.vaccinate(to_vaccinate);
            end

            % Now update infection state vector. Nb this wasn't done before now as it would incorrectly rule out some connections (between nodes who have been infected this time step)
            self.indiv_state(infect_all) = 1;

            % Update Q
            self.counters.Q(self.today+1) = self.Q;

        end

        %% See who recovers (currently very simple)
        function [self] = recovery(self)
           % old method
%             % Find recover force (dependant on symptoms)
%             recover_force = self.indiv_state .* (self.symp .* self.R(2) + ~self.symp .* self.R(1));
%             
%             % See who recovers
%             recovers = rand(self.Q,1) < recover_force;
%             self.indiv_state = self.indiv_state - recovers;
% new method
            % ### See who recovers naturally ###
           
            recovers_naturally = rand(self.Q,1) < self.GAMMA * self.indiv_state; %logical index of those who have recovered naturally this time step
            
            % Update the infection and symptom state arrays
            self.indiv_state = self.indiv_state - recovers_naturally; 
            self.symp(recovers_naturally) = 0;

            % ### See who recovers due to tracing ### (relies on how many recently treated partners they have)
            
            % Update who is currently having their contacts traced
            self.currently_tracing_for = (self.today - self.treated_on) <= self.TRACE_WINDOW(2) & (self.today - self.treated_on) >= self.TRACE_WINDOW(1);
            
            % Find how many contacts that are currently having their contacts traced each agent has
            num_tracing_contacts = self.adj * self.currently_tracing_for';
           
            % Find recovery force due to contact tracing for each infected agent
            trace_recovery_force = (1 - (( 1 - repmat(self.PSI,self.Q,1)) .^ num_tracing_contacts)) .* self.indiv_state;

            % See who recovers due to tracing
            recovers_via_trace = rand(self.Q,1) < trace_recovery_force;
            
            % Add those who have just recovered to the vector tracking who has recovered due to treatment this time step
            newly_recovered_via_treat = recovers_via_trace;

            % Update the infection and symptom state arrays
            self.indiv_state = self.indiv_state - recovers_via_trace;
            self.symp(recovers_via_trace) = 0;

            % ### See who recovers due to self-seeking treatment ### (relies on symptoms)
            
            recovers_via_self_seek = rand(self.Q,1) < self.symp .* self.SELF_SEEK_PROB ;

            % Add those who have just recovered via self-seeking treatment to the vector tracking who has recovered due to treatment this time step
            newly_recovered_via_treat = newly_recovered_via_treat | recovers_via_self_seek;
            
            % Update the incidence counter
            self.counters.incidence(self.today + 1) = sum(newly_recovered_via_treat);

            % Update the infection and symptoms state array
            self.indiv_state = self.indiv_state - recovers_via_self_seek;
            self.symp(recovers_via_self_seek) = 0;

           

            % ### Update recovery state arrays ###
            
            % Find all who have recovered today (via treatment and naturally)
            recovered_today = newly_recovered_via_treat | recovers_naturally;
            
            % Make a note of when each person who was treated was treated
            self.treated_on(newly_recovered_via_treat) = self.today;
   
            % Update compartments
            self.S = self.S + [sum(recovered_today .* ~self.sex), sum(recovered_today .* self.sex)];
            self.I = self.I - [sum(recovered_today .* ~self.sex), sum(recovered_today .* self.sex)];

            % If vaccine offer at treatment is the strategy, then see who gets vaccinated. do the deciding of who gets vaccinated inside the current method
            if self.OFFER_VAC_AT_TREAT == true
                
                idx_to_vaccinate = rand(self.Q ,1) < newly_recovered_via_treat .* self.VAC_UPTAKE_TREAT;

                [self] = self.vaccinate(idx_to_vaccinate); %call method to see who gets vaccinated, and with what level of protection
            
            end
        
        end

        %% Vaccination of agents- (ported over from ABM) 
            function [self] = vaccinate(self,newly_vaccinated) 
                % Method to assign vaccine protection and update relevant states to the agents in the vector 'newly_vaccinated'
                % Inputs: newly_vaccinated - a Q x 1 matrix, where a 1 indicates the agent is to be vaccinated

                % Update vaccine dose counter
                self.counters.n_vaccinated(self.today+1) = self.counters.n_vaccinated(self.today+1) + sum(newly_vaccinated(:,1));

                % Prealocate protection
                newly_vaccinated = [newly_vaccinated, zeros(self.Q,1)];

                % Assign vaccine protection
                if self.ALLOW_VACCINE_DEG == true %check what type of vaccination is being modelled (degree or take)
                    newly_vaccinated(:,2) = newly_vaccinated(:,1) * self.EFFICACY_DEG; % degree type: everyone gets the same level of protection
                
                elseif self.ALLOW_VACCINE_TAKE == true 
                      newly_vaccinated(:,2) = double(rand(self.Q,1) < newly_vaccinated(:,1) .* self.EFFICACY_TAKE); %take type: randomly assign full protection 
               
                end
                
                % ### Update state arrays ###

                % Update network states
                self.vaccinated = self.vaccinated + newly_vaccinated;

%                 % Update compartments ?* can be deleted if I decide against vaccine compartments
%                 % Male and infected
%                 self.I(1,1) = self.I(1,1) - sum(newly_vaccinated(:,1) .* self.indiv_state .* ~self.sex); 
%                 self.I(1,2) = self.I(1,2) + sum(newly_vaccinated(:,1) .* self.indiv_state .* ~self.sex); 
%                 % Male and suscpetible
%                 self.S(1,1) = self.S(1,1) - sum(newly_vaccinated(:,1) .* ~self.indiv_state .* ~self.sex); 
%                 self.S(1,2) = self.S(1,2) + sum(newly_vaccinated(:,1) .* ~self.indiv_state .* ~self.sex); 
%                 % Female and infected
%                 self.I(2,1) = self.I(2,1) - sum(newly_vaccinated(:,1) .* self.indiv_state .* self.sex); 
%                 self.I(2,2) = self.I(2,2) + sum(newly_vaccinated(:,1) .* self.indiv_state .* self.sex); 
%                 % Female and susceptible
%                 self.S(2,1) = self.S(2,1) - sum(newly_vaccinated(:,1) .* ~self.indiv_state .* self.sex); 
%                 self.S(2,2) = self.S(2,2) + sum(newly_vaccinated(:,1) .* ~self.indiv_state .* self.sex);          
               
            end

            function [ self ] = restrict_adj3(self) %!* this needs to be adapted to fit the hybrid model
          %% Returns a restricted partnership network where individiuals
            % referenced in idx_mod have n_to_remove partnerships removed
            % randomly from the original adjacency matrix

            % ### In the hybrid version we need to find other_rels each time the network is restricted ###
            % ?* or should this be done each time the the network is changed (less work?)

                self.num_partners_full = full(sum(self.adj_full,2));

                % set default daily partnership network
                self.adj = self.adj_full;
                self.num_partners = self.num_partners_full;
                
                % restrict daily partnership network by limiting -----
                % individuals to a max number of partners per day
                partner_check = self.num_partners_full - self.RESTRICT_MAX_PARTNERS; %A F: How many partners to bin
                self.id_casuals = [find(partner_check > 0), partner_check(partner_check>0)]; % AF: [index of people deemed too promiscuous, degree of transgression]
                
                % pre-calculate fixed and prunable links
                self.fixed_rels = self.rel_list_full; 
                
                % fixed links  (won't include any links to nodes with
                % degree > threshold) 
                for ii = self.id_casuals(:,1)' 
                    id_remove = self.fixed_rels(:,1) == ii | self.fixed_rels(:,2) == ii;
                    self.fixed_rels(id_remove,:) = []; 
                end
                % prunable links AF: all the links that connect to someone
                % who has been deemed too promiscuous
                self.other_rels = setdiff(self.rel_list_full, self.fixed_rels,'rows');

                % check to see if we can skip this reduction 
                if self.RESTRICT_MAX_PARTNERS < self.FULL_MAX_PARTNERS
                    
                    % default - no links accepted
                    idx = false(length(self.other_rels),1);
                    
                    % zero degrees for (all) nodes
                    ds_check = zeros(sum(self.N),1);

                    % Initialise vector tracking how many infected-agent-edges each susceptible agent has so far in the new adj.
                    inf_edges = zeros(self.Q,1);
                    
                    % loop - check each link in random order
                    for ii = randperm(size(self.other_rels,1))

                        % this relationship (two nodes)
                        rel = self.other_rels(ii,:)';

%                         % Check at least one node is infected
%                         if self.indiv_state(rel(1)) == false && self.indiv_state(rel(2)) == false
%                             continue
%                         end
                        
                        % Decide which case it is (inf-inf, inf-susc, susc-inf)
                        if self.indiv_state(rel(1)) == true  && self.indiv_state(rel(2)) == true

                            if max(ds_check(rel)) < self.RESTRICT_MAX_PARTNERS
                                % accept link if degrees are under threshold
                                idx(ii) = 1;
   
                                % increment degree of both nodes
                                ds_check(rel) = ds_check(rel)+1;
                            end

                        elseif self.indiv_state(rel(1)) == true && self.indiv_state(rel(2)) == false %i.e. the first node in the relation is infected but the second isnt

                            if max(ds_check(rel(1))) < self.RESTRICT_MAX_PARTNERS 
                                % Potentially accept link if inf_agent degree is under threshold

                                if self.d(rel(2)) < self.RESTRICT_MAX_PARTNERS %if the susceptible agent has a desired degree less than the restriction limit, it will always accept a link
                                    % Accept link
                                    idx(ii) = 1;

                                    % increment degree of both nodes
                                    ds_check(rel) = ds_check(rel)+1;

                                    % Increment the number of inf-edges the susc_agent has
                                    inf_edges(rel(2)) = inf_edges(rel(2)) + 1;


                                else % if the des degree is high than the restriction limit, then we decide using probability
                                    idx(ii) = rand(1) < (self.RESTRICT_MAX_PARTNERS - inf_edges(rel(2))) / (self.d(rel(2)) - inf_edges(rel(2)));

                                    % increment degree of both nodes
                                    ds_check(rel) = ds_check(rel) + idx(ii);

                                    % Increment the number of inf-edges the susc_agent has
                                    inf_edges(rel(2)) = inf_edges(rel(2)) + idx(ii);
                                end
                            end

                        elseif self.indiv_state(rel(2)) == true && self.indiv_state(rel(1)) == false
                           
                            if max(ds_check(rel(2))) < self.RESTRICT_MAX_PARTNERS 
                                % Potentially accept link if inf_agent degree is under threshold

                                if self.d(rel(1)) < self.RESTRICT_MAX_PARTNERS %if the susceptible agent has a desired degree less than the restriction limit, it will always accept a link
                                    % Accept link
                                    idx(ii) = 1;

                                    % increment degree of both nodes
                                    ds_check(rel) = ds_check(rel)+1;

                                    % Increment the number of inf-edges the susc_agent has
                                    inf_edges(rel(1)) = inf_edges(rel(1)) + 1;


                                else % if the des degree is high than the restriction limit, then we decide using probability
                                    idx(ii) = rand(1) < (self.RESTRICT_MAX_PARTNERS - inf_edges(rel(1))) / (self.d(rel(1)) - inf_edges(rel(1)));

                                    % increment degree of both nodes
                                    ds_check(rel) = ds_check(rel) + idx(ii);

                                    % Increment the number of inf-edges the susc_agent has
                                    inf_edges(rel(1)) = inf_edges(rel(1)) + idx(ii);
                                end
                            end
                        end

                    end

                    % combine fixed edges with allowed random edges
                    new_rels = cat(1,self.fixed_rels,self.other_rels(idx,:));

                    % update adjacency matrix
                    self.adj = sparse( [new_rels(:,1); new_rels(:,2)], [new_rels(:,2); new_rels(:,1)], 1, self.Q, self.Q);
                    
                    % update degree sequence of current network
                    self.num_partners = full(sum(self.adj,2));
                    
                    self.adj = full(self.adj); %!* only temporary, untill I deal with sparse throughout

                 

                    % checks
%                     sym_out = issymmetric(self.adj)
%                     max_deg_old = max(full(sum(self.adj_full,2)))
%                     max_deg_new = max(full(sum(self.adj,2)))

    
                    if max(self.num_partners) > self.RESTRICT_MAX_PARTNERS
                        error('Network restriction failed!');
                    end
                    
                    % AF: NEW! Long matrix to track adj over time
                    % self.adj_long(:,:,end+1)=full(self.adj);

                end

            end
        %% Graphics
        function [] = display_network(self)
            current_graph = graph(self.adj);
            current_plot = plot(current_graph);
    
            % Colour the nodes
            highlight(current_plot,self.indiv_state == 0,'NodeColor','#13508E'); %highlight susepctible nodes
            highlight(current_plot,self.indiv_state == 1,'NodeColor','#AD3717'); %highlight infected nodes
            
            % Change shape to show male and female
            highlight(current_plot,self.sex == 0,'Marker','square','MarkerSize',5); %male nodes become squares
            highlight(current_plot,self.sex == 1,'Marker','o','MarkerSize',5); %female nodes become circles
            pause(self.PAUSE_LENGTH) 

            
      
        end

        %% Test nothing has gone (obviously) wrong
%         function [] = bug_tests(self)
%             if self.S + self.I ~= self.N
%                 error('S + I ~= N')
%             end
%             
%             if sum(self.v_net + self.v_comp) ~= self.N
%                 error('v_net and v_comp have gone wrong')
%             end
% 
%             if sum(self.adj_full(:) > 1) > 0
%                 error('non-binary element in adjacency matrix')
%             end
%         end

    end
%% Static Methods
    methods (Static)

        %% Create the initial network
        % !* should change this so I don't need to repeat male and female. Also I now have better ways to write a lot of this stuff.
       
        function [self] = create_network(self)
            d_min = 1; % set minimum degree. It'll always be 1. Will it? !*
           
            % ### Create compartment node degree bins ###
            
            true_max_deg = max(self.MAX_DEG);%find max of the male and female maximum degree values
            
            % Males
            node_degree_m = ( ( self.MAX_DEG(1)^(-self.ALPHA(1)+1) - d_min^(-self.ALPHA(1)+1) ).*rand(sum(self.N(1)),1) + d_min^(-self.ALPHA(1)+1) ).^( 1/(-self.ALPHA(1)+1) ); %create a scale-free distribution
            node_deg_round_m = round(node_degree_m); %round this distribution so it makes sense. Should this be floor? !*
            self.u(:,1) = histcounts(node_deg_round_m,0.5:1:true_max_deg + 0.5); %count the instances of each degree
            
            % Females
            node_degree_f = ( ( self.MAX_DEG(2)^(-self.ALPHA(2)+1) - d_min^(-self.ALPHA(2)+1) ).*rand(sum(self.N(2)),1) + d_min^(-self.ALPHA(2)+1) ).^( 1/(-self.ALPHA(2)+1) );
            node_deg_round_f = round(node_degree_f);
            self.u(:,2) = histcounts(node_deg_round_f,0.5:1:true_max_deg + 0.5);
    
            % ### Select (weighted) random degrees. Weighted means that if there are 2 nodes of degree 3 and 1 node of degree 4, then then the probability of choosing 
            % a node of degree 3 is twice that of choosing one of degree 4. ###
            
            % Node degrees for infected males in initial network
            u_bins_m = [0 ;cumsum(self.u(:,1)/sum(self.u(:,1)))]; %these are the edges for the random assignment
            degree_list_m = discretize(rand(self.I(1),1),u_bins_m); %each element tells you which degree one of the initialy infected nodes should be 
            self.v(:,1) = histcounts(degree_list_m,0.5:1:true_max_deg + 0.5); %add the selected node degrees to v_net
            self.u(:,1) = self.u(:,1) - self.v(:,1); %remove the selected node degrees from v_comp
            
            % Node degrees for infected females in initial network
            u_bins_f = [0 ;cumsum(self.u(:,2)/sum(self.u(:,2)))]; %these are the edges for the random assignment
            degree_list_f = discretize(rand(self.I(2),1),u_bins_f);
            self.v(:,2) = histcounts(degree_list_f,0.5:1:true_max_deg + 0.5); %add the selected node degrees to v_net
            self.u(:,2) = self.u(:,2) - self.v(:,2); %remove the selected node degrees from v_comp

            % ### Update state arrays
            
            self.Q = sum(self.I); %total number in the network is currently just the number of infected agents
            self.adj_full = zeros(self.Q); %there are currently no connections 
            self.d = [degree_list_m; degree_list_f]; 
            self.indiv_state = ones(sum(self.I),1); %everyone in the network at the moment is infected
            self.sex = [zeros(self.I(1),1); ones(self.I(2),1)]; %males are tagged with a 0, females with a 1
            self.symp(1:self.I(1),1) = rand(self.I(1),1) < self.SYM_RATE(1); %assign symptoms to males
            self.symp(self.I(1)+1:sum(self.I),1) = rand(self.I(2),1) < self.SYM_RATE(2); %assign symptoms to females
            self.currently_tracing_for(1:sum(self.I),1) = 0; %Q x 1 
            self.treated_on(1:sum(self.I)) = NaN;
            % ### Assign edges to these nodes
           
            self.degree_delta = self.d - sum(self.adj_full,2); %find how many stubs each node has left *! what is the purpose of this?
         
            % !* The following process for choosing neighbour node degrees is temporary. Will use neural net or conditional probabilities.
            % !* Need to change this process so that the degree is found first, then, based on how many nodes are in network vs compartment, weighted-randomly choose network or compartment.
            for ii = randperm(sum(self.I))

               while self.degree_delta(ii) > 0
                   net_prop = self.Q / sum(self.N); %proportion of population in the network
                  
                   if rand < net_prop  %check to see if this node is connecting to an existing node, or is drawing from S
                       % !* this section isnt even drawing from a distribution.
                       
                       % make list of possible connections: constraints are sex, already connected and stubs
                        pos_contacts = self.sex ~= self.sex(ii); %eliminate nodes of same sex from the possible contacts vector
                        pos_contacts = pos_contacts .* ~self.adj_full(:,ii); %eliminate existing contacts of ii
                        pos_contacts = pos_contacts .* self.degree_delta > 0; %eliminate nodes with no space left 

                        pos_cont_idx = find(pos_contacts); %find index values of all possible new contacts
                        
                        if sum(pos_cont_idx) == 0 %if there's no possible contact, then just carry on
                            
                            self.degree_delta(ii) = self.degree_delta(ii) - 1; %need to remove one from degree_delta, or we'll be stuck in the while-loop forever.
                            % !* is this going to cause issues later? Interplay between degree_delta and d?
                            
                            continue
                        end
                        
                        new_contact = randsample(pos_cont_idx,1); %pick one at random

                        % Update state arrays
                        self.adj_full(ii,new_contact) = 1; self.adj_full(new_contact,ii) = 1; %add the new edge to the adjacency matrix
                        self.rel_list_full = [self.rel_list_full; [ii,new_contact]]; %add new edge to the full relation list (only need to add one copy, the list is unordered)
                        self.degree_delta([ii, new_contact]) = self.degree_delta([ii, new_contact]) - 1;
                       
                   else %otherwise draw a new node from S
                       if self.sex(ii) == 0 % i.e. if ii is a male node
                           u_bins_f = [0 ;cumsum(self.u(:,2)/sum(self.u(:,2)))]; %!* somehow this has created a vector that doesn't increase monotonically
                          % add break here
                           new_degree = discretize(rand(1),u_bins_f);
                           self.v(:,2) = self.v(:,2) + histcounts(new_degree,0.5:1:true_max_deg + 0.5)'; %add the selected node degrees to v_net
                           self.u(:,2) = self.u(:,2) - histcounts(new_degree,0.5:1:true_max_deg + 0.5)'; %remove from v_comp

                            % Update state arrays
                            self.Q = self.Q + 1; %nb the network index of added nodes will always be Q + 1
                            self.adj_full(ii,self.Q) = 1; self.adj_full(self.Q,ii) = 1; %add the new edge to the adjacency matrix
                            self.rel_list_full = [self.rel_list_full; [ii,self.Q]];
                            self.d(end+1) = new_degree;
                            self.indiv_state(end+1) = 0;
                            self.sex(end+1) = 1; 
                            self.symp(end+1) = 0;
                            self.degree_delta(ii) = self.degree_delta(ii) - 1; 
                            self.degree_delta(end+1) = new_degree - 1; % add the degree delta of the new node 
                            self.currently_tracing_for(self.Q) = 0; %Q x 1 
                            self.treated_on(self.Q) = NaN;
                            

                       else %if ii is a female node
                           u_bins_m = [0 ;cumsum(self.u(:,1)/sum(self.u(:,1)))];
                           new_degree = discretize(rand(1),u_bins_m);
                           self.v(:,1) = self.v(:,1) + histcounts(new_degree,0.5:1:true_max_deg + 0.5)'; %add the selected node degrees to v_net
                           self.u(:,1) = self.u(:,1) - histcounts(new_degree,0.5:1:true_max_deg + 0.5)'; %remove from v_comp
    
    
                            % Update state arrays
                            self.Q = self.Q + 1; %nb the network index of added nodes will always be Q + 1
                            self.adj_full(ii,self.Q) = 1; self.adj_full(self.Q,ii) = 1; %add the new edge to the adjacency matrix
                            self.rel_list_full = [self.rel_list_full; [ii,self.Q]];
                            self.d(end+1) = new_degree;
                            self.indiv_state(end+1) = 0;
                            self.sex(end+1) = 0;
                            self.symp(end+1) = 0; %we're
                            self.degree_delta(ii) = self.degree_delta(ii) - 1;
                            self.degree_delta(end+1) = new_degree - 1;
                            self.currently_tracing_for(self.Q) = 0; %Q x 1 
                            self.treated_on(self.Q) = NaN;
                            
                       end
                   end
               end
        
            end
            % ### update v_net ### !* will put this in a better place when rewriting the network creator

            self.v(:,1) =  histcounts(~self.sex .* ~self.indiv_state .* self.d ,0.5:1:true_max_deg + 0.5)';
            self.v(:,2) =  histcounts(self.sex .* ~self.indiv_state .* self.d ,0.5:1:true_max_deg + 0.5)';
            self.vaccinated =  zeros(self.Q,2); 

           


            % ### Initial vaccination ###

            idx_to_vaccinate = rand(self.Q,1) < self.VAC_INIT_COVERAGE; %
            [self] = self.vaccinate(idx_to_vaccinate);

           
        end
    end
end