% File for creating/altering and saving parameter file needed to run the
% hybrid model.


params_hybrid.P0 = [0.003,0.003];
params_hybrid.ALPHA = [3.1,2.5];
params_hybrid.BETA = [1,0.1];
params_hybrid.BETA(1) = params_hybrid.BETA(2)/2.5;
params_hybrid.SYM_RATE = [0.9,0.5];
params_hybrid.MAX_DEG = [100,100];
params_hybrid.ENABLE_GRAPHICS = false;
params_hybrid.pause_length = 0.5;
params_hybrid.ALLOW_VACCINE_DEG = false;
params_hybrid.ALLOW_VACCINE_TAKE = false;
params_hybrid.VAC_UPTAKE_TREAT = 0;
params_hybrid.VAC_UPTAKE_UNTARGET = 0;
params_hybrid.OFFER_VAC_AT_TREAT = false;
params_hybrid.EFFICACY_DEG = 0.4;
params_hybrid.OFFER_VAC_UNTARGET = false;
params_hybrid.OFFER_VAC_COHORT = true;
params_hybrid.VAC_INIT_COVERAGE = 0.87;
params_hybrid.EFFICACY_TAKE = 0.7;
params_hybrid.GAMMA = 0.0068;
params_hybrid.PSI = 0.05;
params_hybrid.TRACE_WINDOW = [4,7];
params_hybrid.SELF_SEEK_PROB = 0.05;
params_hybrid.RESTRICT_MAX_PARTNERS = 10;
params_hybrid.FULL_MAX_PARTNERS = 100;
params_hybrid.RESTRICT_PERIOD = 7;


save("params_hybrid.mat","params_hybrid")
