% Script to run Hybrid_Model.m
% Based on run_simple.m by Zienkiewicz et al.
%% Setup
tic
% ### Simulation parmeters ###
N = [50000,50000]; % [# males, # females]
n_Days = 10*365; % days to simulate

% ### Load other parameters ###
load('params_hybrid.mat','params_hybrid');

% ### Space to alter parameters ###
params_hybrid.ENABLE_GRAPHICS = false;
params_hybrid.pause_length = 0.5;
params_hybrid.OFFER_VAC_AT_TREAT = false; 
params_hybrid.ALLOW_VACCINE_DEG = false;
params_hybrid.RESTRICT_MAX_PARTNERS = 10;




%% Run simulation

% ### Create instance of class (i.e. initialise model) ###

hybrid_model = Hybrid_Model_2(N,params_hybrid);

% ### Run the simulation ###

hybrid_model.simulate(n_Days)
toc

%% Graphs and stuff

% ### Graph of prevalence ###

figure
plot(0:n_Days,hybrid_model.counters.total_infected/sum(N))
title('Prevalence of Infection', 'FontSize',16,Interpreter='latex')
xlabel('Days',FontSize=16,Interpreter='latex')
ylabel('Proportion of population infected',FontSize=16,Interpreter='latex')


