% Script to run Hybrid_Model_2.m multiple times
%% Parameters for outermost loop (repeated runs)
runs_n = 2;
lastN = 600;
n_Days = 10*365; % days to simulate
%% Setup for outermost loop
% want to know (to start with):


% Initialise 
Hybrid_Multi_run_data = {};
overall_time0 = datetime;
prev_matrix = zeros(runs_n,n_Days+1);
tic
for ii = 1:runs_n

    ii
    %% Setup
    
    % ### Simulation parmeters ###
    N = [50000,50000]; % [# males, # females]
    
    
    % ### Load other parameters ###
    load('params_hybrid.mat','params_hybrid');
    
    % ### Space to alter parameters ###
    params_hybrid.P0 = [0.0033,0.0033];
    params_hybrid.ALPHA = [3.1,2.5];
    params_hybrid.BETA = [1,0.3];
    params_hybrid.BETA(1) = params_hybrid.BETA(2)/2.5;
    

    
    
    
    
    %% Run simulation
    
    % ### Create instance of class (i.e. initialise model) ###
    
    hybrid_model = Hybrid_Model_2(N,params_hybrid);
    
    % ### Run the Simulation ###
    
    hybrid_model.simulate(n_Days)
    
    % ### colate Data ###
    
    Hybrid_Multi_run_data{ii} = hybrid_model.counters;
    inci_vector(ii) = sum(hybrid_model.counters.incidence(end-lastN+1:end))/(lastN * sum(N));
    %Full_Hybrid_multi_cell{ii} = hybrid_model;
    prev_matrix(ii,:) = (hybrid_model.counters.total_infected);
    %     prev_vector(ii) = sum(hybrid_model.counters.


end
toc
%% Save Data
save("2Hybrid_Multi_run_data_100k_10yr_x20.mat","Hybrid_Multi_run_data")
%save("Full_Hybrid_multi_cell_100k_10yr_x20.mat","Full_Hybrid_multi_cell")

% Find SD of average prevalence
%std(inci_vector);

% Find Average Prevalence over last N
%av_inci_lastN = sum(inci_vector) / runs_n; %average prevalence per person per day over the final lastN days of the sim
%
%save("Exposition2_10000_25.mat","Hybrid_Multi_run_data")
% save("Extra_Control200_2000_5*365_full.mat","Extra_data")
% Refind prevalence vector from cell
% prev_matrix = zeros(runs_n,3651);
% for ii = 1:runs_n
%      prev_matrix(ii,:) = (Hybrid_Multi_run_data{ii}.total_infected);
% end
figure
plot(0:n_Days,sum(prev_matrix)/(sum(N)*runs_n))
title('Prevalence of Infection', 'FontSize',16,Interpreter='latex')
xlabel('Days',FontSize=16,Interpreter='latex')
ylabel('Proportion of population infected',FontSize=16,Interpreter='latex')



