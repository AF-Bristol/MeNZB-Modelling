% Parameter fitting: Vaccine protection (vac (Degree) (bisection)

% Final value of C (midpoint) is the estimate for the parameter vac_eff



%% ### Inputs ###

Int0 = [0.05 0.15]; %itital guess of the interval for BETA_f
%rat = 2.5; %ratio of BETA_f to BETA_m
num_runs = 10; %how many times to run the model to estimate the stat for each parameter value
relTol = 0.05; %how close to the desired stat do we need to be before we stop the process 
des_tot_eff = 0.31; %Desired incidence per person per day
lastN = 100; %number of days to take the average incidence over. E.g. average over the last 100 days of the simulation
max_iterations = 10;
given_inci0 = 1.9828e-04;
find_inci0 = false;
 % General parmeters for the model
    N_m = 6000;          % population size
    N_f= 6000;
    n_Days = 10*365;     % days to simulate
    N = N_m + N_f;

    VERBOSE = false;
    LOW_MEM = false;
    
% load preset simulation parameters from external file
    load('base_params.mat','params');
 
params.BETA_f = 0.0158;
params.BETA_m = params.BETA_f/2.5;
%% ### Initialise ###

inci0_vec = zeros(num_runs,1);

% Find incidence w/o vaccine
if find_inci0 == true
    for j = 1:num_runs*3
    
        % initialise model (create new model object)
            gono_model = AMR_IBM(N_m,N_f, params, [], VERBOSE, LOW_MEM);
            
        % run simulation for n_Days # of days
           
            gono_model.simulate(n_Days);
    
        % Find the prevalence per person per day for the final lastN days from this run
            inci0_vec(j) = sum(gono_model.counters.incidence(end-lastN+1:end,1)) / (N*lastN); %matrix containing the final incidence perperson per day for the final 100 days
    
    end
    
    % Find single incidence value w/o vaccine. This is a reference value through the rest of the code
    inci0 = sum(inci0_vec(:,1))/(num_runs*3);
else 
    inci0 = given_inci0;
end
    
% Update parameters for runs w/ vaccine
params.ALLOW_VACCINE_DEG = true;
params.INITIAL_VAC_COVER_m = 0.86;
params.INITIAL_VAC_COVER_f = 0.86;

inci_mat = zeros(num_runs,2); %preallocation
% Find change in incidence w/ vaccine at the initial end points
for ii = 1:2
    
    params.EFFICACY_DEG = Int0(ii);
    
    for j = 1:num_runs
    
        % initialise model (create new model object)
            gono_model = AMR_IBM(N_m,N_f, params, [], VERBOSE, LOW_MEM);
            
        % run simulation for n_Days # of days
           
            gono_model.simulate(n_Days);
    
        % Find the prevalence per person per day for the final lastN days from this run
            inci_mat(j,ii) = sum(gono_model.counters.incidence(end-lastN+1:end,1)) / (N*lastN); %matrix containing the final prevalence from each run

    end

end



% Find single prevalence values (mean)
inci = [sum(inci_mat(:,1)),NaN,sum(inci_mat(:,2))] / num_runs;

% Find vaccine total effectiveness
tot_eff = [(inci0-inci(1))/inci0,NaN,(inci0-inci(3))/inci0];

% % Find single incidence values (mean)
% inci = sum(inci_mat(:,1))/num_runs;

% Get the initial end points
A = Int0(1);
B = Int0(2);

% Initialise the absolute error
relErr = inf;

%Initialise counter
Counter = 0;
%% ### Iterative Fitting ###

while relErr > relTol && Counter < max_iterations

    % Update counter
    Counter = Counter + 1;

    % Find midpoint
    C = (A + B) / 2;
    
    
    % Preallocate vector w/ prevalence data from each run
    inci_data = zeros(num_runs,1);

    % Find incidence at midpoint 

    params.EFFICACY_DEG = C;

    for j = 1:num_runs

        % initialise model (create new model object)
            gono_model = AMR_IBM(N_m,N_f, params, [], VERBOSE, LOW_MEM);
            
        % run simulation for n_Days # of days
           
            gono_model.simulate(n_Days);

        % Find the prevalence from this run
            inci_data(j) = sum(gono_model.counters.incidence(end-lastN+1:end,1)) / (N*lastN);
    end
    
    % Find mean incidence
    inci(2) = sum(inci_data) / num_runs;

    % Update total effectiveness
    tot_eff(2) = (inci0-inci(2))/inci0;

    % Update the error
    relErr = abs((des_tot_eff - tot_eff(2))/des_tot_eff); %abs differences between the midpoint generated stat and the desired stat

    % Decide on new interval (i.e. update end points)
    
    if des_tot_eff < tot_eff(2)
        B = C; %midpoint becomes the new upper endpoint (i.e. the interval becomes [A,C])
        tot_eff(3) = tot_eff(2); % update prevalence vector
    else
        A = C; %midpoint becomes the new lower endpoint (i.e. the interval becomes [C,B])
        tot_eff(1) = tot_eff(2); % update prevalence vector
    end

end


Counter
C

save("vaccine_eff.mat","C")




