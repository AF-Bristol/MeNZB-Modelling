% Parameter fitting: BETA_m & BETA_f (bisection)

% We have constraints that BETA_f = a * BETA_m
%   This means that we just adjust one of them, BETA_f, and let BETA_m be half of that

% Final value of C (midpoint) is the estimate for the paramter beta_f.
% beta_m is beta_f/2.5



%% ### Inputs ###

Int0 = [0 0.02]; %itital guess of the interval for BETA_f
rat = 2.5; %ratio of BETA_f to BETA_m
num_runs = 10; %how many times to run the model to estimate the stat for each parameter value
relTol = 0.05; %how close to the desired stat do we need to be before we stop the process 
des_inci = 3.4e-5; %Desired incidence per person per day
lastN = 200; %number of days to take the average incidence over. E.g. average over the last 100 days of the simulation
max_iterations = 15;
 % General parmeters for the model
    N_m = 6000;          % population size
    N_f= 6000;
    n_Days = 8*365;     % days to simulate
    N = N_m + N_f;

    VERBOSE = false;
    LOW_MEM = false;
    
% load preset simulation parameters from external file
    load('base_params.mat','params');
 
% you can edit (baseline) parameters by overwriting the preset values, e.g.
%     params.P_SYMPTOMS = 0.5;%
%     params.LAB_DELAY_MEAN = 12;%
    % initial strain prevalence:
        % p0(1) = overall initial prevalence of gonorrhea (0.1 = 10%)
        % p0(2) = proportion of positive cases with AMR component
        % p0(3) = proportion of coinfection given AMR
%         params.p0 = [0.01 0 0];
%         params.EFFICACY_DEG = 0.5;
%         params.EFFICACY_TAKE = 0.5;
%         params.ALLOW_VACCINE_DEG = false;
%         params.ALLOW_VACCINE_TAKE = false;
%         params.VACCINE_UPTAKE = 0.8;
%         %params.INITIAL_VAC_COVER_m = 0.8;
%         %params.INITIAL_VAC_COVER_f = 0.8;
%         params.ALPHA_m = 2.5;
%         params.ALPHA_f = 3.1;
%         params.OFFER_AT_SCREENING = false;
%% ### Initialise ###

inci_mat = zeros(num_runs,2);

% Find stat from end points
for ii = 1:2
    params.BETA_f = Int0(ii);
    params.BETA_m = Int0(ii) / rat;
    
    for j = 1:num_runs
    
        % initialise model (create new model object)
            gono_model = AMR_IBM(N_m,N_f, params, [], VERBOSE, LOW_MEM);
            
        % run simulation for n_Days # of days
           
            gono_model.simulate(n_Days);
    
        % Find the prevalence per person per day for the final lastN days from this run
            inci_mat(j,ii) = sum(gono_model.counters.incidence(end-lastN+1:end,1)) / (N*lastN); %matrix containing the final prevalence from each run

    end

end


% Find single prevalence values (mean)
inci = [sum(inci_mat(:,1)), NaN, sum(inci_mat(:,2))] / num_runs;

% Get the initial end points
A = Int0(1);
B = Int0(2);

% Initialise the absolute error
relErr = inf;

%Initialise counter
Counter = 0;
%% ### Iterative Fitting ###

while relErr > relTol && Counter < max_iterations

    % Update counter
    Counter = Counter + 1;

    % 

    % Find midpoint
    C = (A + B) / 2;

%     %Display interval and prevalence vector (just whilst testing)
%     [A,C,B];
   
    
    
    % Preallocate vector w/ prevalence data from each run
    inci_data = zeros(num_runs,1);

    % Find incidence at midpoint 

    params.BETA_f = C;
    params.BETA_m = C / rat;

    for j = 1:num_runs

        % initialise model (create new model object)
            gono_model = AMR_IBM(N_m,N_f, params, [], VERBOSE, LOW_MEM);
            
        % run simulation for n_Days # of days
           
            gono_model.simulate(n_Days);

        % Find the prevalence from this run
            inci_data(j) = sum(gono_model.counters.incidence(end-lastN+1:end,1)) / (N*lastN);
    end
    
    

    % Update incidence vector (i.e. find mean)
    inci(2) = sum(inci_data) / num_runs;

    % Update the error
    relErr = abs((des_inci - inci(2))/des_inci); %abs differences between the midpoint generated stat and the desired stat
   
    % Update interval long


    %Decide on new interval (i.e. update end points)
    
    if des_inci < inci(2)
        B = C; %midpoint becomes the new upper endpoint (i.e. the interval becomes [A,C])
        inci(3) = inci(2); % update prevalence vector
    else
        A = C; %midpoint becomes the new lower endpoint (i.e. the interval becomes [C,B])
        inci(1) = inci(2); % update prevalence vector
    end

   
    

end


Counter
C






