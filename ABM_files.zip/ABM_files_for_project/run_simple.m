%% Simplified script to initialise, run and plot model output
% (single model run)
tic
    clear

    % General parmeters 
        N_m = 20000;          % population size
        N_f= 20000;
        n_Days = 5*365;     % days to simulate
        N = N_m + N_f;
    
        VERBOSE = false;
        LOW_MEM = false;
        
    % load preset simulation parameters from external file
        load('base_params.mat','params');
     
    % you can edit (baseline) parameters by overwriting the preset values, e.g.
       
        % initial strain prevalence:
            % p0(1) = overall initial prevalence of gonorrhea (0.1 = 10%)
            % p0(2) = proportion of positive cases with AMR component
            % p0(3) = proportion of coinfection given AMR
%             params.p0 = [0.01 0 0];
%             params.EFFICACY_DEG = 1;
%             params.EFFICACY_TAKE = 0.5;
%             params.BETA_f = 0.0085;
%             params.BETA_m = 0.00425;
%             params.ALLOW_VACCINE_DEG = false;
%             params.ALLOW_VACCINE_TAKE = false;
%             params.VACCINE_UPTAKE = 0.8;
%             %params.INITIAL_VAC_COVER_m = 0.8;
%             %params.INITIAL_VAC_COVER_f = 0.8;
%             params.ALPHA_m = 2.5;
%             params.ALPHA_f = 3.1;
%             params.OFFER_AT_TREAT = false;
%             params.OFFER_UNTARGETED = false;

            
           
            

    % display all parameters
        params
        
    %% initialise model (create new model object)
        gono_model = AMR_IBM(N_m,N_f, params, [], VERBOSE, LOW_MEM);
        
    %% run simulation for n_Days # of days
        % n_Days = 365; 
        gono_model.simulate(n_Days);
    
    %% extract all counter data from model object 
    % (or can be referenced directly)
            data = gono_model.counters
            toc

%         % plot prevalence time-series for whole simulation
%         % (using my built in function)
%             gono_model.plot_prev(data, [0 n_Days], [])
%         
%         % manual plots (examples)
%             % get prevalence (per strain) from counter variable
%             % (not yet normalised with respect to the population size)
%                 prev_data = 100*data.prevalence./N;
%                 
%                 figure('name','Strain prevalence');
%                     hold on;
%                     plot([0:n_Days],prev_data(:,1),'b-'); % non AMR strain
%                     plot([0:n_Days],prev_data(:,2),'r-'); % AMR strain
%                     legend('non-AMR','AMR');
%                     xlabel('Time (days)')
%                     ylabel('Prevalence (%)');
%                     box on;
%                     grid on;
%             
%             % drug administration of each drug given by the cumulative sum
%             % of the daily dosage of each drug
%                 figure('name','Dosage','color','w');
%                     hold on;
%                     plot([0:n_Days], cumsum(data.cipr),'b-');
%                     plot([0:n_Days], cumsum(data.cefta),'r-');
%                     legend('Cipr/A','Ceft/A','location','northwest');
%                     xlabel('Time (days)');
%                     ylabel('Number of doses')
%                     title('Cumulative drug doses administered');
%                     box on;
%                     grid on;
