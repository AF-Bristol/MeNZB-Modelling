% Script to update and save parameters to the .mat file that is loaded in multi_run_simple.m


params.p0 = [0.01,0,0];
params.ALPHA_m = 2.5; 
params.ALPHA_f = 3.1;
params.BETA_m = 0.0008;
params.BETA_f = 0.002;
params.GAMMA_m = 0;
params.GAMMA_f = 0;
params.P_SYMPTOMS_m = 0.9;
params.P_SYMPTOMS_f = 0.5;
params.PRESCREEN_TRACED = true;
params.ALLOW_VACCINE_DEG = false;
params.ALLOW_VACCINE_TAKE = false;
params.EFFICACY_DEG = 0; 
params.EFFICACY_TAKE = 0;
params.OFFER_AT_TREAT = false;
params.OFFER_UNTARGETED = false;
params.VACCINE_UPTAKE = 0;
params.INITIAL_VAC_COVER_m = 0;
params.INITIAL_VAC_COVER_f = 0;
params.EXTERNAL_INFECTION_PROB_m = 0;
params.EXTERNAL_INFECTION_PROB_f = 0;
params.DISCRIM_POCT = false;
params.PRESCREEN_TRACED = true;
params.PRESCREEN_SEEKED = true;
params.OFFER_UNTARGETED = false;
params.VACCINE_UPTAKE_UNTARGETED = 0;
params.FULL_MAX_PARTNERS = 120;
params.R = 0.0068;
params.MU = 4.6e-5;
params.P_SEEKS_TREATMENT = 0.66;
params.NON_AMR_MAX_DELAY = inf;
params.NON_AMR_MAX_PARTNERS = inf;
params.RESTRICT_MAX_PARTNERS = 10;
params.RESTRICT_RATE = 7;
params.LAB_DELAY_MEAN = 10;
params.LAB_DELAY_STD = 1;
params.ONSET_DELAY_MEAN = 5;
params.ONSET_DELAY_STD = 1;
params.SEEK_DELAY_MEAN = 10;
params.SEEK_DELAY_STD = 2;
params.RECALL_DELAY_MEAN = 2;
params.RECALL_DELAY_STD = 0.5;
params.TRACE_DELAY_MEAN = 7;
params.TRACE_DELAY_STD = 1;
params.P_BLINDTREAT_AS_AMR = true;
params.ENABLE_nonAMR_RECALL = true;
params.ENABLE_nonAMR_TRACE = true;
params.PRESCREEN_TRACED = true;
params.PRESCREEN_SEEKED = true;
params.ENABLE_POCT = false;
params.DISCRIM_POCT = false;
params.ALLOW_COINFECTION = false;
params.ALLOW_TREAT = true;
params.PSI = 0.1;
params.MAX_TRACE = 5;
params.burn_in = false;


% Save as .mat 
save('base_params.mat',"params")