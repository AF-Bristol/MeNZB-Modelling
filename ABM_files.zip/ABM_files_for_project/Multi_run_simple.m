% Script to run AMR_IBM multiple times and compile results
% (based on run_simple.m)
tic
%% Parameters for outermost loop (repeated runs)
runs_n = 20;


%% Setup for outermost loop
% want to know (to start with):


% Initialise 
Multi_run_data = {};
overall_time0 = datetime;


for ii = 1:runs_n
    % Start time
    time0 = datetime;
ii
    % General parmeters 
        N_m = 6000;          % population size
        N_f= 6000;
        n_Days = 10*365;     % days to simulate
        N = N_m + N_f;
    
        VERBOSE = false;
        LOW_MEM = false;
        
    % load preset simulation parameters from external file
        load('base_params.mat','params');
     
    % you can edit (baseline) parameters by overwriting the preset values, e.g.
        
        % initial strain prevalence:
            % p0(1) = overall initial prevalence of gonorrhea (0.1 = 10%)
            % p0(2) = proportion of positive cases with AMR component
            % p0(3) = proportion of coinfection given AMR
            params.p0 = [0.01 0 0];
            params.EFFICACY_DEG = 0.075;
            params.EFFICACY_TAKE = 0.0312;
            params.BETA_f = 0.015;
            params.BETA_m = params.BETA_f/2.5;
            params.ALLOW_VACCINE_DEG = false;
            params.ALLOW_VACCINE_TAKE = false;
            params.VACCINE_UPTAKE = 0.9;
            %params.INITIAL_VAC_COVER_m = 0.8;
            %params.INITIAL_VAC_COVER_f = 0.8;
            params.ALPHA_m = 2.5;
            params.ALPHA_f = 3.1;
            params.OFFER_AT_TREAT = false;
            params.OFFER_UNTARGETED = false;
            params.INITIAL_VAC_COVER_m = 0;
            params.INITIAL_VAC_COVER_f = 0;
            

    % display all parameters
        params;
        
    %% initialise model (create new model object)
        gono_model = AMR_IBM(N_m,N_f, params, [], VERBOSE, LOW_MEM);
        
    %% run simulation for n_Days # of days
        % n_Days = 365; 
        gono_model.simulate(n_Days);
    
    % Calculate run time
        gono_model.counters.duration = datetime-time0;
        %% extract all counter data from model object 
    % (or can be referenced directly)

            data = gono_model.counters;


        Multi_run_data{ii} = gono_model.counters;
%         ex_data.state_last_x = gono_model.indiv_state(:,1,end+1-last_x:end);
%         ex_data.degree = gono_model.num_partners_full;
%         Extra_data{ii} = ex_data;
           

end
toc
overall_duration = datetime- overall_time0
Multi_run_data{end+1} = overall_duration;
save("Exposition2_10000_25.mat","Multi_run_data")
% save("Extra_Control200_2000_5*365_full.mat","Extra_data")

%% Do stuff with data
% Initailise
sum_prev_either = zeros(n_Days + 1,1);
% Averages (mean)
for ii = 1:runs_n %this finds sums
    % Prevalence of either strain (men and women combined)
    current_data_set = Multi_run_data{ii};
    sum_prev_either = sum_prev_either + current_data_set.prev_either;

end

% find (normalised) averages
av_prev_either = sum_prev_either ./ (runs_n * N); % mean value of the prevalence at each time step

figure
plot(0:n_Days,av_prev_either)
formatSpec = 'Average prevalence over %d runs.';
title(sprintf(formatSpec,runs_n))
xlabel('Day')
ylabel('Proportion infected')



