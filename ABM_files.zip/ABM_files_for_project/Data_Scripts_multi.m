%% Plot the prevalence of each run
for ii = 1:runs_n
    figure
    plot(0:n_Days,Multi_run_data{ii}.prev_either*100/(N))
end

%% Plot a histogram of the average prevalence over the final 100 days
finalday = zeros(runs_n,1);
for ii = 1:runs_n
    final = Multi_run_data{ii}.prev_either(n_Days-99:n_Days);
    finalday(ii) = sum(final/(100*N));
end

sort(finalday)
figure
scatter(1:runs_n,sort(finalday))
title('Average infections over the final 100 days')
    
figure
histogram(finalday,8)

%% Investigate on what day the infection is eradicated
erad_day = nan(runs_n,1);
for ii = 1:runs_n
    if Multi_run_data{ii}.prev_either(end) == 0
        erad_day(ii) = min(find(Multi_run_data{ii}.prev_either(:) == 0));
    end
end

histogram(erad_day,10)

%% Plot all prevalence curves
figure
hold on
for ii = 1:runs_n
    plot(0:n_Days,Multi_run_data{ii}.prev_either*100/(Multi_run_data{ii}.N))

end
hold off

%% Find how many vaccinations were given
runs_n = 100;
total_num_vaccines = 0;
all_data = AtTreat_12k_full; %Place to input data set
for ii = 1:runs_n
    this_data = all_data{ii};
    total_num_vaccines = total_num_vaccines + sum(this_data.n_vaccinated)
end

% Find average (mean)

av_vac_doses = total_num_vaccines/runs_n

%% Find +/- 1 s.d. curves
N = 12000;
runs_n = 100;
all_data = AtTreat_12k_full; %Place to input data set
n_Days = 10*365;
all_prev_data = zeros(runs_n,n_Days+1);

% Put the prevalence data in a runs_n x n_Days+1 matrix
for ii = 1:runs_n
    all_prev_data(ii,:) = all_data{ii}.prevalence(:,1)';
end

% Find s.d. for each day (1 x n_Days+1)
prev_sd_each_day = zeros(1,n_Days+1);

for ii = 1:n_Days+1
    prev_sd_each_day(ii) = std(all_prev_data(:,ii));
end

% PLot 95% C.I. and mean
% x = randi(50, 1, 100);                      % Create Data
% SEM = std(x)/sqrt(length(x));               % Standard Error
% ts = tinv([0.025  0.975],length(x)-1);      % T-Score
% CI = mean(x) + ts*SEM; 
CI_vec = zeros(2,n_Days+1);
for ii = 1:n_Days+1
    todays_prev = all_prev_data(:,ii); %column
    st_err = std(todays_prev) / sqrt(runs_n); %standard error
    ts = tinv([0.025  0.975],100-1);
    CI_vec(:,ii) = (mean(todays_prev) + ts*st_err')/N; 
end
X = 0:n_Days;
% Blue (control)
% plot(X,CI_vec(1,:),"Color",'#2446F0',LineStyle=':',LineWidth=0.75) %lower CI
% hold on
% plot(X,CI_vec(2,:),"Color",'#2446F0',LineStyle=':',LineWidth=0.75) %upper CI
% prev_mean = sum(all_prev_data)/(N*runs_n);
% plot(X,prev_mean,"Color",'#2446F0',LineWidth=1.5)

% Green (high cohort)
% plot(X,CI_vec(1,:),"Color",'#14A321',LineStyle=':',LineWidth=0.75) %lower CI
% hold on
% plot(X,CI_vec(2,:),"Color",'#14A321',LineStyle=':',LineWidth=0.75) %upper CI
% prev_mean = sum(all_prev_data)/(N*runs_n);
% plot(X,prev_mean,"Color",'#14A321',LineWidth=1.5)

%Magenta (med cohort)
% plot(X,CI_vec(1,:),LineStyle=':',LineWidth=0.5,Color="#7E2F8E") %lower CI
% hold on
% plot(X,CI_vec(2,:),"Color","#7E2F8E",LineStyle=':',LineWidth=0.5) %upper CI
% prev_mean = sum(all_prev_data)/(N*runs_n);
% plot(X,prev_mean,"Color","#7E2F8E",LineWidth=1.5)

% Orange (at treatment)
plot(X,CI_vec(1,:),Color="#D95319",LineStyle=":") %lower CI
hold on
plot(X,CI_vec(2,:),Color="#D95319",LineStyle=":") %upper CI
prev_mean = sum(all_prev_data)/(N*runs_n);
plot(X,prev_mean,LineWidth=1.5,Color="#D95319")

%% Average prevalence at the end of the sim
Multi_run_data = full_control_data;
 finalday = zeros(100,1);
for ii = 1:100
    finalday(ii) = Multi_run_data{ii}.prev_either(end);
    
end
finalday_av = sum(finalday) / (100*12000);

%% Av prev for last N days with 95% CI
Multi_run_data = full_medCohort_data;
lastN = 3*365;
n_Days = 10*365;
runs_n = 100;
final = zeros(runs_n,1);
N = 12000;

for ii = 1:runs_n
    final(ii) = sum(Multi_run_data{ii}.prev_either(n_Days-lastN+1:n_Days))/(N*lastN);
end

final_av = sum(final)/runs_n

% CI interval
st_err = std(final) / sqrt(runs_n); %standard error
ts = tinv([0.025  0.975],length(final)-1);
CI = (mean(final) + ts*st_err)

%% Total dose stuff
dataSet = AtTreat_12k_full;
% Cumalative doses
dose_matrix = zeros(100,3651);

for ii = 1:100
    dose_matrix(ii,:) = dataSet{ii}.cipr;
end

% %Average cum doses
% dose_matrix(:,1:1000) = [];
% av_cumDoses = cumsum(sum(dose_matrix)/100);
% max(av_cumDoses)

% x day rolling average
roll_num = 30;
av_xday_av = zeros(1,3650-roll_num+1);
for ii = roll_num:3650
    av_xday_av(ii-roll_num+1) = sum(sum(dose_matrix(:,ii-roll_num+1:ii)))/100;
end

plot(roll_num:3650,av_xday_av,LineWidth=1.5,Color="#D95319")



% % Plot
% X = 1001:3651;
% plot(X,av_cumDoses)





   









